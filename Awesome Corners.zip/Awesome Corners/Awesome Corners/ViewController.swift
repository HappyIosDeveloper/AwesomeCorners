//
//  ViewController.swift
//  Awesome Corners
//
//  Created by Ahmadreza on 9/3/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var whiteCellWithSoftShowView: UIView!
    @IBOutlet weak var roundButton: UIButton!
    @IBOutlet weak var circleButton: UIButton!
    @IBOutlet weak var circleView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
    }
}

// MARK: - Setup Functions
extension ViewController {
    
    
    func setupViews() {
        whiteCellWithSoftShowView.dropShadowAndCornerRadious(.large)
        roundButton.roundUp(.large)
        circleButton.roundUp(.round)
        circleView.dropShadowAndCornerRadious(.round)
    }
}
